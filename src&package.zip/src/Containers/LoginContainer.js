import {connect} from 'react-redux'
import ScreenLogin from '../Screens/ScreenLogin'
const mapStateToProps= state =>({

})
const mapDispatchToProps = {
}
export default connect(
    mapStateToProps,
    mapDispatchToProps,
)(ScreenLogin)