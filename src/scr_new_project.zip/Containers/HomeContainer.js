import {connect} from 'react-redux'
import ScreenHome from '../Screens/ScreenHome'
const mapStateToProps = state =>({
    
})
const mapDispatchToProps ={

}
export default connect(
    mapStateToProps,
    mapDispatchToProps,
)(ScreenHome)