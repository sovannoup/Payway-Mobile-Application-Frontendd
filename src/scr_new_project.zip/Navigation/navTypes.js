export const NAV_TYPES = {
    LOGIN : "LOGIN",
    HOME : "HOME",
    INTRO: "INTRO",
    CORE: "CORE",
    START_UP: "START_UP",
    MAIN: "MAIN",
    MAIN_HOME: "MAIN_HOME"
};